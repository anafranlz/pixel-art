package read;

	import java.awt.Color;
	import java.awt.Graphics2D;
	import java.awt.image.BufferedImage;
	import java.io.File;
	import javax.imageio.ImageIO;

		public class KnucklesPixelArt {
			
			// Definimos el tamano de la imagen en ancho y alto
			private static int width = 1280;
		    private static int height = 1400;
		    
		    // Definimos el tamano del pixel
		    private static int PIXEL_SIZE = 40;
		    private static Graphics2D g;
		    //el graphics2d es el que nos permite hacer cuadrados, circulos, etc
		    
		    // Definimos los colores a usar
		    static Color white 		= Color.white;
		    static Color blue  		= Color.blue;
		    static Color black      = Color.black;
		    static Color red   		= new Color(184,0,0);
		    static Color softRed 	= new Color(248,33,0);
		    static Color vino 		= new Color(112,0,0);
		    static Color lapizYellow = new Color(248,248,152);
		    static Color brown = new Color(152,81,1);
		    static Color softBrown	= new Color(248,166,80);
		    static Color grey 		= new Color(112,112,112);
		    static Color softGrey = new Color(176,176,176);
		    static Color brightGreen = new Color(112,248,0);
		    static Color green 		= new Color(0,168,17);
		    static Color yellow 	= new Color(248,215,0);
		    
		    static BufferedImage image = new BufferedImage(width, height, BufferedImage.TYPE_INT_RGB);
		    
		    public static void paint() {
		    	drawBackground(PIXEL_SIZE, Color.white);     
		        drawHorizontalLine(7, 11, 1, red);
		        drawHorizontalLine(6, 14, 2, red);
		        drawHorizontalLine(7, 12, 2, softRed);
		        drawHorizontalLine(5, 16, 3, red);
		        drawHorizontalLine(6, 14, 3, softRed);
		        drawHorizontalLine(4, 17, 4, red);
		        drawHorizontalLine(5, 16, 4, softRed);
		        drawHorizontalLine(3, 18, 5, red);
		        drawHorizontalLine(3, 19, 6, red);
		        drawHorizontalLine(4, 17, 5, softRed);
		        drawHorizontalLine(4, 18, 6, softRed);
		        drawVerticalLine(5, 6, 5, red);
		        putPixel(6, 4, red);
		        drawHorizontalLine(2, 19, 7, red);
		        drawHorizontalLine(2, 20, 8, red);
		        putPixel(20, 7, vino);
		        putPixel(9, 5, red);
		        putPixel(15, 5, red);
		        drawHorizontalLine(3, 18, 7, softRed);
		        drawHorizontalLine(3, 20, 8, softRed);
		        putPixel(21, 8, vino);
		        drawHorizontalLine(13, 14, 6, red);
		        drawHorizontalLine(1, 20, 9, red);
		        drawHorizontalLine(1, 20, 10, red);
		        drawHorizontalLine(1, 19, 11, red);
		        putPixel(16, 6, red);
		        putPixel(7, 8, red);
		        putPixel(15, 7, red);
		        putPixel(17, 7, red);
		        drawVerticalLine(6, 8, 8, red);
		        drawHorizontalLine(1, 19, 12, red);
		        drawHorizontalLine(1, 21, 13, black);
		        drawHorizontalLine(1, 20, 14, black);
		        drawHorizontalLine(1, 18, 15, black);
		        fillRect(13, 7, 2, 4, white);
		        drawVerticalLine(7, 8, 12, vino);
		        drawVerticalLine(9, 10, 11, vino);
		        drawVerticalLine(9, 10, 12, red);
		        putPixel(15, 8, white);
		        putPixel(16, 8, red);
		        putPixel(18, 8, red);
		        drawVerticalLine(7, 9, 4, red);
		        fillRect(14, 10, 3, 2, white);
		        drawVerticalLine(9, 11, 15, blue);
		        putPixel(15, 10, black);
		        drawHorizontalLine(1, 18, 16, black);
		        drawVerticalLine(9, 16, 1, red);
		        drawVerticalLine(9, 11, 2, softRed);
		        drawVerticalLine(9, 11, 3, vino);
		        fillRect(4, 10, 2, 3, softRed);
		        drawHorizontalLine(5, 6, 9, softRed);
		        putPixel(6, 10, softRed);
		        drawVerticalLine(9, 10, 7, vino);
		        fillRect(8, 9, 2, 4, softRed);
		        drawVerticalLine(9, 10, 10, softRed);
		        putPixel(16, 9, red);
		        putPixel(18, 9, red);
		        putPixel(17, 9, softRed);
		        putPixel(19, 9, softRed);
		        putPixel(20, 9, vino);
		        drawVerticalLine(10, 11, 17, vino);
		        drawHorizontalLine(18, 19, 10, red);
		        putPixel(20, 10, vino);
		        putPixel(19, 11, vino);
		        putPixel(18, 11, red);
		        drawVerticalLine(11, 12, 6, red);
		        drawVerticalLine(11, 13, 7, black);
		        drawVerticalLine(11, 12, 10, red);
		        drawHorizontalLine(11, 12, 11, vino);
		        putPixel(13, 11, red);
		        drawHorizontalLine(18, 19, 12, vino);
		        drawVerticalLine(12, 13, 2, red);
		        drawVerticalLine(14, 16, 2, vino);
		        drawVerticalLine(13, 14, 4, softRed);
		        drawVerticalLine(13, 14, 5, red);
		        putPixel(4, 15, red);
		        putPixel(5, 15, vino);
		        drawVerticalLine(16, 17, 4, vino);
		        putPixel(8, 13, red);
		        putPixel(9, 13, softRed);
		        drawVerticalLine(13, 14, 10, vino);
		        drawVerticalLine(14, 15, 9, red);
		        putPixel(7, 14, vino);
		        drawVerticalLine(15, 17, 11, red);
		        putPixel(6, 16, white);
		        putPixel(8, 16, red);
		        putPixel(12, 15, vino);
		        putPixel(12, 16, red);
		        drawVerticalLine(12, 13, 12, softBrown);
		        putPixel(13, 12, lapizYellow);
		        putPixel(12, 14, brown);
		        putPixel(14, 12, softBrown);
		        drawHorizontalLine(15, 17, 12, brown);
		        putPixel(13, 13, brown);
		        putPixel(13, 14, softBrown);
		        drawHorizontalLine(14, 17, 13, lapizYellow);
		        drawHorizontalLine(14, 15, 14, lapizYellow);
		        putPixel(18, 13, softBrown);
		        putPixel(16, 14, softBrown);
		        drawHorizontalLine(17, 18, 14, brown);
		        putPixel(14, 16, grey);
		        putPixel(15, 16, softGrey);
		        drawHorizontalLine(16, 17, 16, white);
		        drawHorizontalLine(19, 20, 16, white);
		        drawHorizontalLine(21, 22, 16, grey);
		        drawHorizontalLine(23, 25, 16, black);
		        drawVerticalLine(17, 18, 1, vino);
		        putPixel(1, 19, black);
		        drawVerticalLine(17, 21, 2, black);
		        drawVerticalLine(18, 19, 4, black);
		        putPixel(5, 17, black);
		        drawVerticalLine(17, 20, 7, black);
		        drawVerticalLine(17, 19, 10, black);
		        putPixel(9, 17, black);
		        drawVerticalLine(17, 20, 8, softRed);
		        drawVerticalLine(18, 19, 9, red);
		        drawHorizontalLine(9, 10, 20, softRed);
		        drawHorizontalLine(6, 12, 34, black);
		        putPixel(12, 17, black);
		        putPixel(11, 18, black);
		        putPixel(13, 17, softGrey);
		        putPixel(12, 18, grey);
		        putPixel(16, 17, softGrey);
		        drawVerticalLine(17, 18, 17, black);
		        drawVerticalLine(19, 20, 12, softGrey);
		        putPixel(20, 17, black);
		        putPixel(25, 17, black);
		        putPixel(21, 17, softGrey);
		        drawVerticalLine(17, 18, 23, softGrey);
		        putPixel(21, 18, grey);
		        drawVerticalLine(18, 19, 24, grey);
		        putPixel(17, 19, softGrey);
		        drawVerticalLine(18, 23, 19, black);
		        drawVerticalLine(19, 20, 21, black);
		        putPixel(18, 19, black);
		        putPixel(20, 20, black);
		        putPixel(25, 20, black);
		        drawHorizontalLine(8, 10, 21, black);
		        putPixel(11, 21, softGrey);
		        putPixel(13, 21, softGrey);
		        putPixel(12, 21, grey);
		        drawVerticalLine(20, 21, 16, softGrey);
		        drawVerticalLine(20, 22, 24, softGrey);
		        putPixel(17, 21, grey);
		        putPixel(18, 21, black);
		        putPixel(20, 21, softGrey);
		        putPixel(21, 21, grey);
		        putPixel(26, 21, black);
		        drawHorizontalLine(7, 8, 22, red);
		        putPixel(9, 22, vino);
		        putPixel(10, 22, softRed);
		        drawHorizontalLine(11, 13, 22, black);
		        putPixel(12, 23, black);
		        drawHorizontalLine(14, 15, 22, grey);
		        drawHorizontalLine(16, 17, 22, black);
		        putPixel(18, 22, grey);
		        putPixel(20, 22, grey);
		        putPixel(21, 22, softGrey);
		        putPixel(22, 22, black);
		        putPixel(23, 22, softGrey);
		        putPixel(25, 22, black);
		        drawHorizontalLine(5, 7, 23, vino);
		        drawHorizontalLine(8, 9, 23, black);
		        putPixel(10, 23, red);
		        drawVerticalLine(23, 25, 11, softRed);
		        putPixel(13, 23, brown);
		        putPixel(14, 23, black);
		        drawHorizontalLine(17, 24, 23, black);
		        drawHorizontalLine(3, 4, 24, brown);
		        drawHorizontalLine(4, 6, 24, black);
		        putPixel(10, 24, brown);
		        putPixel(10, 25, black);
		        drawVerticalLine(24, 26, 12, brown);
		        putPixel(13, 24, black);
		        drawVerticalLine(24, 25, 14, brown);
		        drawVerticalLine(24, 26, 15, black);
		        drawHorizontalLine(8, 9, 26, black);
		        putPixel(10, 26, vino);
		        putPixel(11, 26, red);
		        drawHorizontalLine(13, 14, 26, black);
		        drawVerticalLine(27, 29, 7, black);
		        drawVerticalLine(29, 30, 6, black);
		        drawVerticalLine(31, 33, 5, black);
		        drawVerticalLine(27, 28, 12, black);
		        drawVerticalLine(27, 28, 16, black);
		        drawVerticalLine(28, 29, 14, black);
		        drawVerticalLine(29, 30, 11, black);
		        drawVerticalLine(31, 33, 12, black);
		        drawHorizontalLine(13, 21, 33, black);
		        drawHorizontalLine(9, 10, 29, black);
		        drawHorizontalLine(13, 15, 28, black);
		        putPixel(8, 31, black);
		        putPixel(10, 31, black);
		        putPixel(16, 30, black);
		        putPixel(18, 30, black);
		        putPixel(8, 28, black);
		        putPixel(8, 27, green);
		        putPixel(9, 27, vino);
		        putPixel(11, 27, vino);
		        putPixel(10, 27, red);
		        drawHorizontalLine(13, 15, 27, green);
		        drawHorizontalLine(9, 10, 28, brightGreen);
		        putPixel(11, 28, green);
		        putPixel(8, 29, red);
		        drawHorizontalLine(12, 13, 29, red);
		        putPixel(19, 29, red);
		        drawVerticalLine(29, 30, 15, grey);
		        drawVerticalLine(29, 30, 17, grey);
		        drawVerticalLine(30, 31, 7, grey);
		        drawVerticalLine(30, 31, 9, grey);
		        putPixel(12, 30, red);
		        drawHorizontalLine(13, 14, 30, softBrown);
		        putPixel(13, 31, softBrown);
		        putPixel(20, 30, red);
		        putPixel(19, 30, softRed);
		        drawHorizontalLine(15, 20, 31, softRed);
		        putPixel(21, 31, red);
		        putPixel(14, 31, red);
		        putPixel(11, 31, red);
		        drawVerticalLine(31, 32, 6, yellow);
		        drawHorizontalLine(7, 11, 32, softRed);
		        drawHorizontalLine(13, 14, 32, grey);
		        drawHorizontalLine(15, 20, 32, softGrey);
		        putPixel(21, 32, grey);
		        putPixel(6, 33, grey);
		        putPixel(7, 33, softGrey);
		        putPixel(11, 33, softGrey);
		        drawSquareGrid(PIXEL_SIZE, Color.black);
		        
		        
		        // Guardamos la imagen en formato JPG
		        try {       
		            ImageIO.write(image, "jpg", new File("knuckles_pixel_art.jpg"));
		            System.out.println("EXITO !!!");
		        } catch (Exception e) {
		            e.printStackTrace();
		        }
		    }
		    
		    private static void drawVerticalLine(int a, int b, int x, Color c){
		   	    g.setColor(c);
		    	for(int i=a;i<=b;i++){
		    		 putPixel(x, i, c);
		        }
		    }
		    
		    private static void drawHorizontalLine(int a, int b, int y, Color c){
		    	g.setColor(c);
		        for(int i=a;i<=b;i++){
		        	 putPixel(i, y, c);
		        }
		    }
		    
		    private static void putPixel(int x, int y, Color c){       
			   g.setColor(c);
			   g.fillRect(x * PIXEL_SIZE, y * PIXEL_SIZE, PIXEL_SIZE, PIXEL_SIZE);    
		    }
		    
		    private static void fillRect(int x, int y, int width, int height, Color c){
		    	g.setColor(c);
		    	g.fillRect(x * PIXEL_SIZE, y * PIXEL_SIZE, width*PIXEL_SIZE, height*PIXEL_SIZE);
		    }
		    
		    private static void drawSquareGrid(int size, Color c) {
		    	g.setColor(c);
		        for (int i = 0; i < size; i++) {
		            for (int j = 0; j < size; j++) { 
		                g.drawRect(i * PIXEL_SIZE, j * PIXEL_SIZE, PIXEL_SIZE, PIXEL_SIZE);
		            }
		        }
		    }
		    
		    //wrapper
		    private static void drawBackground(int size, Color c) {
		    	g.setColor(c);
		    	for (int i = 0; i < size; i++) {
		            for (int j = 0; j < size; j++) {
		                g.fillRect(i * PIXEL_SIZE, j * PIXEL_SIZE, PIXEL_SIZE, PIXEL_SIZE);                
		            }
		        }
		    }    
		    
		    public static void main(String[] args) {
		        g = image.createGraphics();        
		        paint();
		    }
		}
