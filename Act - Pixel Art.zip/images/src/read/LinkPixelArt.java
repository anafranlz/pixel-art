package read;

import java.awt.Color;
import java.awt.Graphics2D;
import java.awt.image.BufferedImage;
import java.io.File;

import javax.imageio.ImageIO;

public class LinkPixelArt {

	// Definimos el tamano de la imagen en ancho y alto
				private static int width = 1760;
			    private static int height = 1760;
			    
			    // Definimos el tamano del pixel
			    private static int PIXEL_SIZE = 40;
			    private static Graphics2D g;
			    //el graphics2d es el que nos permite hacer cuadrados, circulos, etc
			    
			    // Definimos los colores a usar
			    static Color darkGreen   		= new Color(73,144,78);
			    static Color black   		= Color.black;
			    static Color green   		= new Color(151,217,127);
			    static Color brown   		= new Color(125,91,56);
			    static Color darkBrown   		= new Color(77,56,35);
			    static Color yellow   		= new Color(237,245,1);
			    static Color darkYellow   		= new Color(255,198,10);
			    static Color skin   		= new Color(227,165,104);
			    static Color white   		= Color.white;
			    static Color eye   		= new Color(7,175,201);
			    static Color brightYellow   		= new Color(248,255,1);
			    static Color lightBlue   		= new Color(156,220,230);
			    static Color blue   		= new Color(0,8,117);
			    static Color grey   		= new Color(200,208,229);
			    static Color darkGrey   		= new Color(150,150,150);
			    static Color red   		= new Color(208,0,0);
			    static Color darkPurple   		= new Color(63,36,117);
			    static Color purple   		= new Color(86,48,159);
			    static Color lightPurple   		= new Color(100,58,186);
			    static Color lila   		= new Color(122,70,230);
			    static Color orange   		= new Color(186,84,59);

			    
			    static BufferedImage image = new BufferedImage(width, height, BufferedImage.TYPE_INT_RGB);
			    
			    public static void paint() {
			    	drawBackground(PIXEL_SIZE, Color.white);     
			    	drawHorizontalLine(21, 25, 1, black);
			    	drawHorizontalLine(19, 27, 2, black);
			    	drawHorizontalLine(21, 25, 2, darkGreen);
			    	drawHorizontalLine(19, 27, 3, darkGreen);
			    	drawHorizontalLine(21, 24, 3, green);
			    	putPixel(18,3,black);
			    	drawHorizontalLine(28, 29, 3, black);
			    	putPixel(33,3,black);
			    	putPixel(17,4,black);
			    	drawHorizontalLine(18, 28, 4, darkGreen);
			    	drawHorizontalLine(19, 26, 4, green);
			    	drawHorizontalLine(32, 34, 4, black);
			    	putPixel(33,4,grey);
			    	drawVerticalLine(5,17,35,black);
			    	drawVerticalLine(5,17,34,white);
			    	drawVerticalLine(5,20,33,grey);
			    	drawVerticalLine(9,10,33,white);
			    	putPixel(33,14,white);
			    	putPixel(33,21,lightBlue);
			    	drawVerticalLine(5,17,32,lightBlue);
			    	drawVerticalLine(8,9,32,grey);
			    	putPixel(32,13,grey);
			    	drawHorizontalLine(16, 31, 5, black);
			    	drawHorizontalLine(17, 29, 5, darkGreen);
			    	drawHorizontalLine(19, 20, 5, green);
			    	drawHorizontalLine(25, 27, 5, green);
			    	drawHorizontalLine(21, 22, 5, brown);
			    	drawHorizontalLine(16, 31, 5, black);
			    	drawHorizontalLine(15, 22, 6, darkYellow);
			    	putPixel(21,6,yellow);
			    	drawHorizontalLine(17, 20, 6, brown);
			    	putPixel(19,6,darkGreen);
			    	putPixel(23,6,brown);
			    	drawHorizontalLine(24, 29, 6, darkGreen);
			    	putPixel(27,6,green);
			    	drawHorizontalLine(29, 30, 4, black);
			    	drawHorizontalLine(30, 31, 6, black);
			    	drawVerticalLine(7,17,31,black);
			    	drawHorizontalLine(24, 30, 7, darkGreen);
			    	drawHorizontalLine(20, 23, 7, darkYellow);
			    	drawHorizontalLine(21, 22, 7, yellow);
			    	drawHorizontalLine(18, 19, 7, brown);
			    	drawHorizontalLine(14, 17, 7, darkYellow);
			    	drawHorizontalLine(15, 16, 7, yellow);
			    	drawVerticalLine(9,13,13,brown);
			    	drawVerticalLine(8,10,14,yellow);
			    	putPixel(14,11,darkYellow);
			    	putPixel(14,12,brown);
			    	drawHorizontalLine(15, 16, 8, yellow);
			    	drawVerticalLine(9,10,15,darkYellow);
			    	drawVerticalLine(11,12,15,brown);
			    	drawVerticalLine(8,11,16,yellow);
			    	putPixel(16,12,darkYellow);
			    	drawVerticalLine(13,14,16,brown);
			    	drawVerticalLine(8,15,17,brown);
			    	drawVerticalLine(10,11,17,black);
			    	drawHorizontalLine(18, 24, 8, darkYellow);
			    	putPixel(19,8,brown);
			    	drawHorizontalLine(20, 23, 8, yellow);
			    	putPixel(21,8,skin);
			    	drawHorizontalLine(25, 30, 8, darkGreen);
			    	drawHorizontalLine(26, 27, 8, black);
			    	drawHorizontalLine(18, 26, 9, brown);
			    	drawHorizontalLine(29, 30, 9, darkGreen);
			    	drawHorizontalLine(27, 28, 9, black);
			    	putPixel(21,9,skin);
			    	drawHorizontalLine(23, 25, 9, darkYellow);
			    	putPixel(24,9,yellow);
			    	drawHorizontalLine(18, 25, 10, brown);
			    	putPixel(20,10,skin);
			    	putPixel(22,10,darkYellow);
			    	putPixel(24,10,darkYellow);
			    	putPixel(26,10,yellow);
			    	putPixel(27,10,darkGreen);
			    	drawHorizontalLine(28, 30, 10, black);
			    	drawVerticalLine(11,13,18,black);
			    	fillRect(19,11,3,3,skin);
			    	drawHorizontalLine(21, 23, 11, black);
			    	drawVerticalLine(11,13,22,black);
			    	fillRect(23,12,2,2,white);
			    	putPixel(23,13,eye);
			    	putPixel(24,12,black);
			    	drawHorizontalLine(24, 30, 11, brown);
			    	putPixel(25,11,darkYellow);
			    	drawHorizontalLine(27, 28, 11, black);
			    	drawHorizontalLine(25, 27, 12, brown);
			    	fillRect(28,12,2,2,skin);
			    	putPixel(29,13,black);
			    	putPixel(30,12,black);
			    	drawVerticalLine(13,18,30,darkGreen);
			    	drawVerticalLine(14,19,29,darkGreen);
			    	putPixel(29,18,black);
			    	fillRect(18,14,7,3,skin);
			    	putPixel(18,15,black);
			    	drawHorizontalLine(17, 19, 16, black);
			    	drawHorizontalLine(23, 24, 16, black);
			    	drawVerticalLine(13,16,25,darkYellow);
			    	drawVerticalLine(13,15,26,yellow);
			    	drawVerticalLine(13,14,27,brown);
			    	drawVerticalLine(14,15,28,black);
			    	drawVerticalLine(15,16,27,black);
			    	drawVerticalLine(16,18,26,black);
			    	putPixel(28,16,darkGreen);
			    	fillRect(27,17,2,2,darkGreen);
			    	putPixel(28,17,black);
			    	putPixel(28,19,darkGreen);
			    	drawHorizontalLine(11, 15, 17, black);
			    	putPixel(17,17,green);
			    	drawHorizontalLine(18, 24, 17, darkGreen);
			    	drawHorizontalLine(19, 22, 17, black);
			    	drawVerticalLine(18,21,32,black);
			    	drawVerticalLine(18,21,34,black);
			    	drawVerticalLine(21,22,31,black);
			    	drawVerticalLine(21,22,35,black);
			    	putPixel(33,22,black);
			    	drawHorizontalLine(32, 34, 23, black);
			    	putPixel(33,23,brightYellow);
			    	putPixel(10,18,black);
			    	putPixel(9,19,black);
			    	drawHorizontalLine(11, 15, 18, darkGrey);
			    	drawVerticalLine(18,22,15,darkGrey);
			    	drawVerticalLine(18,22,16,black);
			    	fillRect(17,18,6,5,darkGreen);
			    	drawHorizontalLine(21, 22, 18, green);
			    	drawHorizontalLine(18, 21, 19, green);
			    	putPixel(18,22,green);
			    	drawHorizontalLine(21, 23, 21, black);
			    	putPixel(22,21,brightYellow);
			    	drawHorizontalLine(20, 22, 22, black);
			    	putPixel(21,22,darkGrey);
			    	fillRect(23,18,3,3,black);
			    	putPixel(23,18,darkGreen);
			    	drawVerticalLine(19,22,26,darkGreen);
			    	drawVerticalLine(20,22,25,darkGreen);
			    	drawVerticalLine(19,22,27,green);
			    	putPixel(24,22,darkGreen);
			    	putPixel(24,21,green);
			    	putPixel(23,22,green);
			    	putPixel(28,20,green);
			    	drawVerticalLine(21,25,28,black);
			    	putPixel(28,24,darkGreen);
			    	drawVerticalLine(19,22,14,black);
			    	fillRect(10,19,4,4,blue);
			    	putPixel(10,19,brightYellow);
			    	putPixel(11,20,brightYellow);
			    	putPixel(10,21,white);
			    	putPixel(9,20,brightYellow);
			    	drawVerticalLine(21,23,9,blue);
			    	drawVerticalLine(20,22,8,black);
			    	drawHorizontalLine(12, 13, 22, red);
			    	drawHorizontalLine(12, 14, 23, blue);
			    	putPixel(12,23,red);
			    	putPixel(10,23,red);
			    	putPixel(8,23,red);
			    	putPixel(15,23,black);
			    	putPixel(16,23,darkGrey);
			    	drawHorizontalLine(17, 26, 23, black);
			    	putPixel(22,23,green);
			    	putPixel(27,23,darkGreen);
			    	drawVerticalLine(19,20,30,black);
			    	putPixel(29,20,black);
			    	drawHorizontalLine(36, 37, 20, black);
			    	drawVerticalLine(21,23,38,black);
			    	putPixel(29,21,lila);
			    	putPixel(36,21,lila);
			    	putPixel(30,21,lightPurple);
			    	putPixel(29,22,lightPurple);
			    	putPixel(36,22,lightPurple);
			    	drawVerticalLine(21,23,37,darkPurple);
			    	drawHorizontalLine(35, 36, 23, purple);
			    	drawHorizontalLine(31, 35, 24, purple);
			    	putPixel(36,24,darkPurple);
			    	putPixel(32,24,darkPurple);
			    	putPixel(30,24,darkPurple);
			    	putPixel(31,23,darkPurple);
			    	putPixel(30,22,darkPurple);
			    	drawHorizontalLine(29, 30, 23, purple);
			    	drawVerticalLine(23,25,7,black);
			    	putPixel(11,23,blue);
			    	putPixel(29,24,black);
			    	putPixel(37,24,black);
			    	drawHorizontalLine(30, 36, 25, black);
			    	drawVerticalLine(26,30,35,black);
			    	drawVerticalLine(27,29,35,darkBrown);
			    	fillRect(8,24,6,2,blue);
			    	putPixel(9,24,red);
			    	putPixel(11,24,red);
			    	drawVerticalLine(25,28,13,black);
			    	drawHorizontalLine(14, 26, 24, black);
			    	putPixel(15,24,darkGrey);
			    	putPixel(22,24,darkGrey);
			    	putPixel(23,24,brightYellow);
			    	putPixel(27,24,darkGreen);
			    	putPixel(27,25,black);
			    	putPixel(29,25,grey);
			    	fillRect(9,26,4,3,blue);
			    	putPixel(10,26,red);
			    	putPixel(12,26,red);
			    	putPixel(9,27,red);
			    	putPixel(11,27,red);
			    	putPixel(10,28,brightYellow);
			    	drawVerticalLine(26,27,8,black);
			    	drawVerticalLine(28,29,9,black);
			    	drawVerticalLine(29,30,10,black);
			    	drawHorizontalLine(11, 14, 29, black);
			    	putPixel(13,29,darkGrey);
			    	drawHorizontalLine(11, 12, 30, darkGrey);
			    	drawHorizontalLine(11, 12, 31, black);
			    	putPixel(13,30,black);
			    	drawVerticalLine(25,28,14,darkGrey);
			    	drawVerticalLine(25,28,15,black);
			    	drawHorizontalLine(16,26,28,black);
			    	drawHorizontalLine(18,26,27,black);
			    	drawHorizontalLine(18,25,26,black);
			    	drawHorizontalLine(16,25,25,black);
			    	putPixel(19,25,darkGreen);
			    	putPixel(24,25,darkGreen);
			    	putPixel(17,25,brown);
			    	drawVerticalLine(26,27,16,brown);
			    	drawVerticalLine(26,27,17,skin);
			    	drawHorizontalLine(19,23,26,darkGreen);
			    	drawVerticalLine(26,29,24,green);
			    	drawVerticalLine(28,29,25,green);
			    	putPixel(25,27,darkGreen);
			    	putPixel(26,29,darkGreen);
			    	putPixel(24,30,darkGreen);
			    	drawVerticalLine(27,31,23,darkGreen);
			    	drawVerticalLine(27,31,22,darkGreen);
			    	drawVerticalLine(27,30,21,green);
			    	drawVerticalLine(27,29,20,darkGreen);
			    	drawVerticalLine(27,30,19,darkGreen);
			    	drawVerticalLine(28,29,19,green);
			    	putPixel(18,28,darkGreen);
			    	putPixel(18,29,green);
			    	putPixel(20,30,green);
			    	putPixel(21,31,darkGreen);
			    	drawVerticalLine(29,32,27,black);
			    	drawHorizontalLine(25,26,30,black);
			    	drawHorizontalLine(25,26,31,darkGrey);
			    	drawVerticalLine(31,37,24,black);
			    	putPixel(24,33,darkGrey);
			    	drawVerticalLine(26,27,29,black);
			    	drawVerticalLine(27,29,30,black);
			    	drawVerticalLine(29,30,31,black);
			    	drawVerticalLine(26,32,32,black);
			    	putPixel(32,30,skin);
			    	drawVerticalLine(26,27,31,skin);
			    	putPixel(30,26,brown);
			    	putPixel(31,28,brown);
			    	drawHorizontalLine(33,34,26,darkBrown);
			    	fillRect(33,27,2,3,orange);
			    	putPixel(33,29,darkBrown);
			    	putPixel(34,30,darkBrown);
			    	drawVerticalLine(30,31,33,black);
			    	putPixel(34,31,black);
			    	putPixel(33,32,purple);
			    	putPixel(34,32,darkPurple);
			    	putPixel(35,32,black);
			    	drawHorizontalLine(17,18,30,black);
			    	drawHorizontalLine(17,20,31,black);
			    	putPixel(18,31,darkGrey);
			    	drawVerticalLine(32,43,16,black);
			    	drawHorizontalLine(15,16,39,darkBrown);
			    	drawVerticalLine(35,43,15,black);
			    	drawVerticalLine(36,37,15,brown);
			    	putPixel(15,41,darkBrown);
			    	drawVerticalLine(36,43,14,black);
			    	drawVerticalLine(39,43,13,black);
			    	drawVerticalLine(40,43,12,black);
			    	drawVerticalLine(40,43,11,black);
			    	putPixel(12,41,darkBrown);
			    	drawHorizontalLine(13,14,41,skin);
			    	drawHorizontalLine(13,14,42,darkBrown);
			    	drawVerticalLine(35,43,17,black);
			    	drawVerticalLine(35,43,18,black);
			    	drawVerticalLine(35,43,19,black);
			    	drawHorizontalLine(17,18,36,skin);
			    	putPixel(19,36,darkBrown);
			    	putPixel(18,37,darkBrown);
			    	putPixel(17,37,skin);
			    	drawVerticalLine(33,39,20,black);
			    	drawVerticalLine(32,34,17,darkGrey);
			    	drawVerticalLine(32,34,19,darkGrey);
			    	putPixel(18,34,darkGrey);
			    	putPixel(20,32,darkGrey);
			    	drawHorizontalLine(21,23,32,black);
			    	putPixel(24,33,darkGrey);
			    	drawHorizontalLine(25,27,34,darkGrey);
			    	drawHorizontalLine(28,29,34,black);
			    	drawHorizontalLine(25,30,35,black);
			    	drawVerticalLine(33,43,28,black);
			    	putPixel(28,39,darkBrown);
			    	putPixel(28,41,darkBrown);
			    	putPixel(28,36,brown);
			    	drawVerticalLine(36,43,27,black);
			    	drawVerticalLine(38,42,26,black);
			    	drawVerticalLine(38,39,25,black);
			    	fillRect(25,36,2,2,skin);
			    	putPixel(25,37,brown);
			    	putPixel(29,36,skin);
			    	putPixel(29,37,brown);
			    	drawVerticalLine(36,43,30,black);
			    	drawHorizontalLine(29,30,41,skin);
			    	drawHorizontalLine(29,30,42,darkBrown);
			    	drawVerticalLine(36,43,31,black);
			    	putPixel(31,41,darkBrown);
			    	drawVerticalLine(41,43,32,black);
			    	drawVerticalLine(38,40,29,black);
			    	putPixel(29,39,darkBrown);
			    	putPixel(27,33,darkGrey);
			    	drawHorizontalLine(33,34,33,black);
			        drawSquareGrid(PIXEL_SIZE, Color.black);
			        
			        
			        // Guardamos la imagen en formato JPG
			        try {       
			            ImageIO.write(image, "jpg", new File("link_pixel_art.jpg"));
			            System.out.println("EXITO !!!");
			        } catch (Exception e) {
			            e.printStackTrace();
			        }
			    }
			    
			    private static void drawVerticalLine(int a, int b, int x, Color c){
			   	    g.setColor(c);
			    	for(int i=a;i<=b;i++){
			    		 putPixel(x, i, c);
			        }
			    }
			    
			    private static void drawHorizontalLine(int a, int b, int y, Color c){
			    	g.setColor(c);
			        for(int i=a;i<=b;i++){
			        	 putPixel(i, y, c);
			        }
			    }
			    
			    private static void putPixel(int x, int y, Color c){       
				   g.setColor(c);
				   g.fillRect(x * PIXEL_SIZE, y * PIXEL_SIZE, PIXEL_SIZE, PIXEL_SIZE);    
			    }
			    
			    private static void fillRect(int x, int y, int width, int height, Color c){
			    	g.setColor(c);
			    	g.fillRect(x * PIXEL_SIZE, y * PIXEL_SIZE, width*PIXEL_SIZE, height*PIXEL_SIZE);
			    }
			    
			    private static void drawSquareGrid(int size, Color c) {
			    	g.setColor(c);
			        for (int i = 0; i < size; i++) {
			            for (int j = 0; j < size; j++) { 
			                g.drawRect(i * PIXEL_SIZE, j * PIXEL_SIZE, PIXEL_SIZE, PIXEL_SIZE);
			            }
			        }
			    }
			    
			    //wrapper
			    private static void drawBackground(int size, Color c) {
			    	g.setColor(c);
			    	for (int i = 0; i < size; i++) {
			            for (int j = 0; j < size; j++) {
			                g.fillRect(i * PIXEL_SIZE, j * PIXEL_SIZE, PIXEL_SIZE, PIXEL_SIZE);                
			            }
			        }
			    }    
			    
			    public static void main(String[] args) {
			        g = image.createGraphics();        
			        paint();
			    }
	
}
